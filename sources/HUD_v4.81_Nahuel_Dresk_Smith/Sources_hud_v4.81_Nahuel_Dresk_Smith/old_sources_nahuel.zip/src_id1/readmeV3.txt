Credits:
Chip, for the great quakewiki.net
Seven, for arranging my code
Unknow programmer, for his great and simple use of csqc
http://www.quakewiki.net/quake-1/mods/custom-hud/
To compile use fteqcc (not included)
Nahuel.
************************************
v3
show players in game and  end stats maps, (kleshik and nexuiz stuff in "kleshikstuff.qc)