Credits:
Nahuel, for his amazing work in making this HIPNOTIC HUD !!!
Chip, for the great quakewiki.net
Seven, for arranging my code
Unknow programmer, for his great and simple use of csqc
http://www.quakewiki.net/quake-1/mods/custom-hud/
To compile use fteqcc
